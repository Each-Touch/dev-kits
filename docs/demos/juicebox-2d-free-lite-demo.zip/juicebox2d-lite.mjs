/**
 * JuiceBox 2D — Free Lite Demo (2 of 12 Modules: CameraShake + Hitstop)
 * Upgrade to Full Commercial Kit ($5.99) for all 12 ES modules, TypeScript .d.ts,
 * 3 standalone HTML5 demos, unit tests, and commercial royalty-free license:
 * https://each-touch.itch.io/juicebox-2d-game-feel-kit
 */

export class CameraShake {
  constructor(opts = {}) {
    this.maxOffsetX = opts.maxOffsetX ?? 18;
    this.maxOffsetY = opts.maxOffsetY ?? 18;
    this.decayPerSec = opts.decayPerSec ?? 2.2;
    this.trauma = 0;
  }
  addTrauma(amount) { this.trauma = Math.min(1, Math.max(0, this.trauma + amount)); }
  update(dt) {
    this.trauma = Math.max(0, this.trauma - this.decayPerSec * dt);
    const s = this.trauma * this.trauma;
    return { x: (Math.random() * 2 - 1) * this.maxOffsetX * s, y: (Math.random() * 2 - 1) * this.maxOffsetY * s };
  }
}

export class Hitstop {
  constructor() { this.remaining = 0; }
  trigger(seconds) { this.remaining = Math.max(this.remaining, Math.max(0, seconds)); }
  step(dt) {
    if (this.remaining <= 0) return false;
    this.remaining = Math.max(0, this.remaining - dt);
    return true;
  }
}
