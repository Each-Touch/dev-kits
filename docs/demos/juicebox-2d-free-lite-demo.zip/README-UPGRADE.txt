JuiceBox 2D — Free Lite Demo (2 of 12 Modules)

Included in this Free Lite Demo:
- juicebox2d-lite.mjs (CameraShake + Hitstop preview)

Upgrade to the Full Commercial Kit ($5.99 USD) to unlock all 12 Modules + TypeScript .d.ts:
1. CameraShake   2. Hitstop       3. SpringValue      4. ParticlePool
5. FloatingText  6. SquashStretch 7. HitFlash         8. MotionTrail
9. TimeScale    10. ImpactAudio  11. InputAssist     12. FpsMonitor
+ 3 Standalone Playable HTML5 Demos + Full node --test Unit Test Suite + Commercial License

Get the Full Kit: https://each-touch.itch.io/juicebox-2d-game-feel-kit
Try Live Interactive Playground: https://each-touch.github.io/dev-kits/juicebox-2d/
